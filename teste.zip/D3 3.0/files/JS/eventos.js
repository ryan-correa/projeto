import { openModal } from 'JS/modal.js';
// Configura eventos globais
document.addEventListener('DOMContentLoaded', function() {
    const modalContatos = document.getElementById('modal-contatos');
    const modalErro = document.getElementById('modal-erro');
    const btnAdicionarContato = document.getElementById('btn-adicionar-contato');
    const formularioContato = document.getElementById('formulario-contato');

    // Adicionar contato
    formularioContato.addEventListener('submit', function(event) {
        event.preventDefault();
        const nome = document.getElementById('nome').value;
        const telefone = document.getElementById('telefone').value;
        const email = document.getElementById('email').value;

        adicionarContato(nome, telefone, email);
        closeModal(modalContatos);
    });

    // Abertura do modal de adicionar contato
    btnAdicionarContato.addEventListener('click', function() {
        openModal(modalContatos);
    });

    // Fechamento do modal de erro
    modalErro.querySelector('.close-erro').addEventListener('click', function() {
        closeModal(modalErro);
    });

    // Fechar modal de contatos ao clicar fora dele
    window.addEventListener('click', function(event) {
        if (event.target === modalContatos) {
            closeModal(modalContatos);
        }
    });
});