document.addEventListener('DOMContentLoaded', function() {
    const listaContatos = document.getElementById('lista-contatos');
    const formularioContato = document.getElementById('formulario-contato');
    const modalContatos = document.getElementById('modal-contatos');
    const btnAdicionarContato = document.getElementById('btn-adicionar-contato');
    const closeModalBtn = document.querySelector('.close');

    function openModal() {
        modalContatos.style.display = 'block';
    }

    function closeModal() {
        modalContatos.style.display = 'none';
    }

    formularioContato.addEventListener('submit', function(event) {
        event.preventDefault();

        const nome = document.getElementById('nome').value;
        const telefone = document.getElementById('telefone').value;
        const email = document.getElementById('email').value;

        // Criação do contato
        const contatoDiv = document.createElement('div');
        contatoDiv.classList.add('contato-nome');
        contatoDiv.classList.add('estilizado'); // Classe de estilo
        contatoDiv.dataset.nome = nome;
        contatoDiv.dataset.telefone = telefone;
        contatoDiv.dataset.email = email;

        contatoDiv.innerHTML = `
            <span class="nome-text">${nome}</span>
        `;

        // Botão de favoritar
        const btnFavoritarContato = document.createElement('button');
        btnFavoritarContato.classList.add('btn-favoritar-contato');
        btnFavoritarContato.textContent = '⭐';
        contatoDiv.appendChild(btnFavoritarContato);

        // Adiciona evento para favoritar
        btnFavoritarContato.addEventListener('click', function(event) {
            event.stopPropagation();
            toggleFavorito(contatoDiv, btnFavoritarContato);
        });

        // Botão de remover
        const btnRemoverContato = document.createElement('button');
        btnRemoverContato.classList.add('btn-remover-contato');
        btnRemoverContato.textContent = '🗑️';
        contatoDiv.appendChild(btnRemoverContato);

        btnRemoverContato.addEventListener('click', function(event) {
            event.stopPropagation();
            contatoDiv.remove();
        });

        // Botão de editar
        const btnEditarContato = document.createElement('button');
        btnEditarContato.classList.add('btn-editar-contato');
        btnEditarContato.textContent = '✏️';
        contatoDiv.appendChild(btnEditarContato);

        btnEditarContato.addEventListener('click', function(event) {
            event.stopPropagation();
            // Aqui você pode chamar o modal de edição
            console.log(`Editar contato: ${contatoDiv.dataset.nome}`);
        });

        // Adiciona o contato à lista
        listaContatos.appendChild(contatoDiv);

        // Fecha o modal e reseta o formulário
        formularioContato.reset();
        closeModal();
    });

    // Função para alternar o estado de favorito
    function toggleFavorito(contato, botaoFavorito) {
        if (contato.classList.contains('favorito')) {
            contato.classList.remove('favorito');
            botaoFavorito.textContent = '⭐';
        } else {
            contato.classList.add('favorito');
            botaoFavorito.textContent = '🌟';
        }
    }

    btnAdicionarContato.addEventListener('click', openModal);
    closeModalBtn.addEventListener('click', closeModal);
});
