document.addEventListener('DOMContentLoaded', function() {
    const modalEditar = document.getElementById('modal-editar');
    const closeEditarBtn = document.querySelector('.close-editar');
    const formularioEditar = document.getElementById('formulario-editar');
    let contatoAtual;

    // Função para abrir o modal de edição com os dados do contato
    function openEditarModal(contato) {
        contatoAtual = contato;
        document.getElementById('editar-nome').value = contato.dataset.nome;
        document.getElementById('editar-telefone').value = contato.dataset.telefone;
        document.getElementById('editar-email').value = contato.dataset.email;
        modalEditar.style.display = 'block'; // Torna o modal visível
    }

    // Função para fechar o modal de edição
    function closeEditarModal() {
        modalEditar.style.display = 'none'; // Torna o modal invisível
    }

    // Função para atualizar os dados do contato
    formularioEditar.addEventListener('submit', function(event) {
        event.preventDefault();

        const nome = document.getElementById('editar-nome').value;
        const telefone = document.getElementById('editar-telefone').value;
        const email = document.getElementById('editar-email').value;

        // Atualizar os dados do contato
        contatoAtual.dataset.nome = nome;
        contatoAtual.dataset.telefone = telefone;
        contatoAtual.dataset.email = email;

        // Atualiza o conteúdo visual do contato
        contatoAtual.querySelector('.nome-contato').textContent = nome;

        // Fechar o modal de edição
        closeEditarModal();
    });

    // Fechar o modal de edição ao clicar no botão de fechar (X)
    closeEditarBtn.addEventListener('click', function() {
        closeEditarModal(); // Chama a função para fechar o modal
    });

    // Adicionar evento de abrir o modal de edição aos botões de lápis
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('icone-editar')) {
            const contatoDiv = event.target.closest('.contato');
            openEditarModal(contatoDiv);
        }
    });
});